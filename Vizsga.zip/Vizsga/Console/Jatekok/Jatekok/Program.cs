﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jatekok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Jatek> lista = Jatek.Beolvas("jatekok.csv");

            Console.WriteLine("Játékok száma: {0}", lista.Count);

            int osszes = 0;
            foreach(Jatek j in lista)
            {
                osszes += j.Ar;
            }
            double atlag = (double) osszes / lista.Count;
            Console.WriteLine("A játékok átlagára: {0:F1}", atlag);

            Console.WriteLine("2018 után kiadott játékok:");
            foreach(Jatek j in lista)
            {
                if (j.KiadasEve > 2018)
                {
                    Console.WriteLine(j.Nev);
                }
            }

            Console.Write("Kérek egy stúdió nevet: ");
            string keres = Console.ReadLine();
            bool van = false;
            foreach (Jatek j in lista) { 
                if(keres == j.Studio)
                {
                    van = true;
                }
            }
            if (van)
            {
                Console.WriteLine("Van ilyen stúdió");
            }
            else
            {
                Console.WriteLine("Nincs ilyen stúdió");
            }

            int max = lista.Max(j => j.Ar);
            foreach(Jatek j in lista)
            {
                if(max == j.Ar)
                {
                    Console.WriteLine("A ledrágább játék: {0}", j.Nev);
                }
            }

            int db50 = 0;
            foreach(Jatek j in lista)
            {
                if(j.Ar > 50)
                {
                    db50++;
                }
            }

            bool vanIngyenes = false;
            foreach(Jatek j in lista)
            {
                if(j.Ar == 0)
                {
                    vanIngyenes = true;
                }
            }
            if (vanIngyenes) {
                Console.WriteLine("Van ingyenes játék");
            }
            else
            {
                Console.WriteLine("Nincs ingyenes játék");
            }

            int legregebbiJatek = lista.Min(j => j.KiadasEve);
            foreach(Jatek j in lista)
            {
                if(j.KiadasEve == legregebbiJatek)
                {
                    Console.WriteLine("A legrégebbi játék: {0}",j.Nev);
                }
            }

            Console.WriteLine("Rockstar játékok: ");
            foreach(Jatek j in lista)
            {
                if(j.Studio == "Rockstar")
                {
                    Console.WriteLine(j.Nev);
                }
            }
        }
    }
}
