﻿using System.Collections.Generic;
using System.IO;

namespace Jatekok
{
    class Jatek
    {
        private int id;
        private string nev;
        private string studio;
        private int kiadasEve;
        private int ar;

        public int Id { get => id; set => id = value; }
        public string Nev { get => nev; set => nev = value; }
        public string Studio { get => studio; set => studio = value; }
        public int KiadasEve { get => kiadasEve; set => kiadasEve = value; }
        public int Ar { get => ar; set => ar = value; }

        public Jatek(int id, string nev, string studio, int kiadasEve, int ar)
        {
            this.Id = id;
            this.Nev = nev;
            this.Studio = studio;
            this.KiadasEve = kiadasEve;
            this.Ar = ar;
        }

        public static List<Jatek> Beolvas(string fnev)
        {
            List<Jatek> lista = new List<Jatek>();
            string[] sorok = File.ReadAllLines(fnev);

            for(int i=0; i < sorok.Length; i++)
            {
                string[] mezo = sorok[i].Split(';');

                Jatek j = new Jatek(int.Parse(mezo[0]), mezo[1], mezo[2], int.Parse(mezo[3]), int.Parse(mezo[4]));
                lista.Add(j);
            }
            return lista;
        }
    }
}
