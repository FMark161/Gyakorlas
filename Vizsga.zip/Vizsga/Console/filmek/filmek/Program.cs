﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace filmek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Filmek> lista = Filmek.Beolvas("filmek.txt");

            Console.WriteLine("Filmek száma: {0}", lista.Count);

            int db = 0;
            int osszes = 0;
            double atlag = 0;
            foreach (Filmek f in lista)
            {
                db += 1;
                osszes += f.JatekIdoP;
            }
            atlag = (double)osszes / db;
            Console.WriteLine("Átlag játékidő: {0:F1}", atlag);

            Console.WriteLine("2010 után készült filmek:");
            foreach (Filmek f in lista)
            {
                if (f.MegjelenesiEv > 2010)
                {
                    Console.WriteLine(f.Cim);
                }
            }

            Console.Write("Adj meg egy rendezőt: ");
            string rendezo = Console.ReadLine();

            bool van = false;
            foreach (Filmek f in lista) { 
                if(rendezo == f.Rendezo)
                {
                    van = true;
                }
            }

            if (van)
            {
                Console.WriteLine("Van ilyen rendező");
            }
            else
            {
                Console.WriteLine("Nincs ilyen rendező");
            }


            int hossz = 0;
            foreach (Filmek f in lista) { 
                if(f.JatekIdoP > hossz)
                {
                    hossz = f.JatekIdoP;
                }
            }

            string maxPfilm = "";
            foreach(Filmek f in lista)
            {
                if(hossz == f.JatekIdoP)
                {
                    maxPfilm = f.Cim;
                }
            }

            Console.WriteLine("A leghosszabb film: {0}", maxPfilm);

            Console.WriteLine("Filmek, amik hosszabbak 150 percnél: ");
            foreach (Filmek f in lista) { 
                if(f.JatekIdoP > 150)
                {
                    Console.WriteLine(f.Cim);
                }
            }

            Console.ReadKey();
        }
    }
}
