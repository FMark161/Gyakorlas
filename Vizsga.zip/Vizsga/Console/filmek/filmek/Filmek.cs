﻿using System.Collections.Generic;
using System.IO;

namespace filmek
{
    class Filmek
    {
        private int id;
        private string cim;
        private string rendezo;
        private int megjelenesiEv;
        private int jatekIdoP;

        public int Id { get => id; set => id = value; }
        public string Cim { get => cim; set => cim = value; }
        public string Rendezo { get => rendezo; set => rendezo = value; }
        public int MegjelenesiEv { get => megjelenesiEv; set => megjelenesiEv = value; }
        public int JatekIdoP { get => jatekIdoP; set => jatekIdoP = value; }

        public Filmek(int id, string cim, string rendezo, int megjelenesiEv, int jatekIdoP)
        {
            this.Id = id;
            this.Cim = cim;
            this.Rendezo = rendezo;
            this.MegjelenesiEv = megjelenesiEv;
            this.JatekIdoP = jatekIdoP;
        }

        public static List<Filmek> Beolvas(string adatok)
        {
            List<Filmek> lista = new List<Filmek>();
            string[] sorok = File.ReadAllLines(adatok);

            for (int i = 0; i < sorok.Length; i++)
            {
                string[] mezo = sorok[i].Split(';');

                Filmek f = new Filmek(int.Parse(mezo[0]), mezo[1], mezo[2], int.Parse(mezo[3]), int.Parse(mezo[4]));
                lista.Add(f);
            }
            return lista;
        }
    }
}
