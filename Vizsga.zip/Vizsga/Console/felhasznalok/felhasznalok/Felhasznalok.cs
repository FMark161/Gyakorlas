﻿using System.Collections.Generic;
using System.IO;

namespace felhasznalok
{
    class Felhasznalok
    {
        private string nev;
        private int magassag;
        private int kor;

        public string Nev { get => nev; set => nev = value; }
        public int Magassag { get => magassag; set => magassag = value; }
        public int Kor { get => kor; set => kor = value; }

        public Felhasznalok(string nev, int magassag, int kor)
        {
            this.Nev = nev;
            this.Magassag = magassag;
            this.Kor = kor;
        }
        public static List<Felhasznalok> Beolvas(string adatok)
        {
            List<Felhasznalok> lista = new List<Felhasznalok>();
            string[] sorok = File.ReadAllLines(adatok);

            for (int i = 0; i < sorok.Length; i++)
            {
                string[] mezo = sorok[i].Split(';');

                Felhasznalok f = new Felhasznalok(mezo[0], int.Parse(mezo[1]), int.Parse(mezo[2]));
                lista.Add(f);
            }
            return lista;
        }
    }
}
