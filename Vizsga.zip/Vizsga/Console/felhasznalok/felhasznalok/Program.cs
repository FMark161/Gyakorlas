﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace felhasznalok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Felhasznalok> lista = Felhasznalok.Beolvas("adatok.txt");

            Console.WriteLine("A könyvek száma {0}", lista.Count);

            int osszeg = 0;
            foreach (Felhasznalok f in lista)
            {
                osszeg += f.Kor;
            }
            double atlag= osszeg/lista.Count;

            Console.WriteLine("Átlag kor: {0:F1}", atlag);

            Console.WriteLine("174 cm-nél magasabb emberek:");

            foreach(Felhasznalok f in lista)
            {
                if (f.Magassag > 174)
                {
                    Console.WriteLine(f.Nev);
                }
            }

            Console.Write("Adj meg egy nevet: ");
            string nev = Console.ReadLine();

            bool van = false;

            foreach(Felhasznalok f in lista)
            {
                if(f.Nev == nev)
                {
                    van = true;
                }
            }

            if (van)
            {
                Console.WriteLine("Van ilyen személy");
            }
            else
            {
                Console.WriteLine("Nincs ilyen személy");
            }
            Console.ReadKey();

        }
    }
}
