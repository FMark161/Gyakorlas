﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bicikli
{
    /// <summary>
    /// Interaction logic for UjBicikliWindow.xaml
    /// </summary>
    public partial class UjBicikliWindow : Window
    {
        public UjBicikliWindow()
        {
            InitializeComponent();
        }

        private void vissza_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            Close();
        }

        public static List<Bicikli> Biciklik = new List<Bicikli>();
        private void mentes_Click(object sender, RoutedEventArgs e)
        {
            Bicikli b = new Bicikli
            {
                marka = bmarka.Text,
                tipus = btipus.Text,
                meret = int.Parse(bmeret.Text),
                ar = int.Parse(bar.Text)
            };
            Biciklik.Add(b);
            MessageBox.Show("Mentve!");
        }
    }
}
