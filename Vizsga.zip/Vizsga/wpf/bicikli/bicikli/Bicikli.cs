﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bicikli
{
    public class Bicikli
    {
        public string marka {  get; set; }
        public string tipus { get; set; }
        public int meret {  get; set; }
        public int ar { get; set; }
    }
}
