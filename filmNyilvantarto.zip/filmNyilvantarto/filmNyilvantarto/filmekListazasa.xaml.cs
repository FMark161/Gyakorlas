﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace filmNyilvantarto
{
    /// <summary>
    /// Interaction logic for filmekListazasa.xaml
    /// </summary>
    public partial class filmekListazasa : Window
    {
        public filmekListazasa()
        {
            InitializeComponent();
        }

        private void vissza_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            Close();
        }

        private void betolt_Click(object sender, RoutedEventArgs e)
        {
            tabla.ItemsSource = ujFilmFelvetele.lista;
        }
    }
}
