﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace filmNyilvantarto
{
    /// <summary>
    /// Interaction logic for ujFilmFelvetele.xaml
    /// </summary>
    public partial class ujFilmFelvetele : Window
    {
        public ujFilmFelvetele()
        {
            InitializeComponent();
        }

        private void vissza_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            Close();
        }

        public static List<Film> lista = new List<Film>();
        private void mentes_Click(object sender, RoutedEventArgs e)
        {
            Film f = new Film
            {
                cim = fcim.Text,
                rendezo = frendezo.Text,
                ev = int.Parse(fev.Text),
                ertekeles = int.Parse(fertekeles.Text)
            };
            lista.Add(f);
            MessageBox.Show("Sikeres hozzáadás!");
            fcim.Clear();
            frendezo.Clear();
            fev.Clear();
            fertekeles.Clear();
        }
    }
}
