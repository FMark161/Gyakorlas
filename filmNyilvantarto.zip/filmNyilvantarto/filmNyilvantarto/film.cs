﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace filmNyilvantarto
{
    public class Film
    {
        public string cim {  get; set; }
        public string rendezo { get; set; }
        public int ev {  get; set; }
        public int ertekeles { get; set; }
    }
}
