﻿using System;
using System.Collections.Generic;
using System.IO;

class program 
{
    static void ListaKiir(List<string> lista)
    {
        foreach (string item in lista)
        {
            Console.WriteLine(item);
        }
    }

    static void MenuKiir()
    {
        Console.WriteLine("VÁLASSZ");
        Console.WriteLine("1 - Bevásárló lista megtekintése");
        Console.WriteLine("2 - Új elem hozzáadása a listához");
        Console.WriteLine("3 - Törlés");
        Console.WriteLine("4 - Kilépés");
    }
    static void Main()
    {
        List<string> bevasarloLista = new List<string>();

        if (File.Exists("lista.txt"))
        {
            bevasarloLista = new List<string>(File.ReadAllLines("lista.txt"));
        }

        bool fut = true;

        while (fut) 
        {
            Console.Clear();

            MenuKiir();

            Console.Write("Választás: ");
            string valasztas = Console.ReadLine();

            if (valasztas == "1") 
            {
                if (bevasarloLista.Count > 0)
                {
                    Console.WriteLine("\nBevásárló lista:");

                    ListaKiir(bevasarloLista);

                    Console.ReadKey();
                }
                else {
                    Console.WriteLine("Nincs termék a listában.");
                    Console.ReadKey();
                }
            }
            else if (valasztas == "2")
            {
                Console.Write("Kérem az új elemet: ");
                string ujElem = Console.ReadLine();

                bevasarloLista.Add(ujElem);
                Mentes(bevasarloLista);
                Console.ReadKey();
            }
            else if (valasztas == "3")
            {
                Console.Write("Hányas elemet szeretné törölni a listából? ");
                int szam = int.Parse(Console.ReadLine());

                bevasarloLista.RemoveAt(szam - 1);
                Mentes(bevasarloLista);
                Console.ReadKey();
            }
            else if (valasztas == "4")
            {
                fut = false;
            }
        }
    }

    static void Mentes(List<string> lista)
    {
        File.WriteAllLines("lista.txt", lista);
    }

}