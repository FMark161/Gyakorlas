﻿using System;
using System.Collections.Generic;
using System.IO;

class program
{
    static void MenuKiiras()
    {
        Console.WriteLine("===FILMNYILVÁNTARTÓ===");
        Console.WriteLine("1 - Film hozzáadása");
        Console.WriteLine("2 - Filmek listázása");
        Console.WriteLine("3 - Film törlése");
        Console.WriteLine("4 - Mentés fájlba");
        Console.WriteLine("5 - Betöltés fájlból");
        Console.WriteLine("6 - Kilépés");
    }

    static void KiIras(List<string> lista)
    {   
        int db = 0;
        foreach (string str in lista)
        {
            db = db + 1;
            Console.WriteLine(db+"."+ " " + str);
        }
    }

    static void Mentes(List<string>lista)
    {
        File.WriteAllLines("filmek.txt", lista);
    }

    static void Betoltes(List<string> lista)
    {
        if (File.Exists("filmek.txt"))
        {
            lista.Clear();

            string[] sorok = File.ReadAllLines("filmek.txt");

            foreach (string sor in sorok)
            {
                lista.Add(sor);
            }

            Console.WriteLine("Sikeres betöltés");
        }
        else
        {
            Console.WriteLine("Hiba a beolvasás során");
        }
    }


    static void Main()
    {
        List<string> filmek = new List<string>();

        bool futas = true;

        while (futas)
        {
            Console.Clear();

            MenuKiiras();
            Console.Write("Válassz egy menüpontot: ");
            string valasz = Console.ReadLine();
            Console.ReadKey();

            if (valasz == "1")
            {
                Console.Write("Új film címe: ");
                string ujCim = Console.ReadLine();
                filmek.Add(ujCim);

                Console.ReadKey();
            }
            else if (valasz == "2")
            {
                if (filmek.Count > 0)
                {
                    Console.WriteLine("Filmek:");
                    KiIras(filmek);
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Nem található adat");
                }
            }
            else if (valasz == "3")
            {
                Console.Write("Törlendő film sorszáma: ");
                int torles = int.Parse(Console.ReadLine());

                filmek.RemoveAt(torles - 1);
            }
            else if (valasz == "4")
            {
                Mentes(filmek);
                Console.WriteLine("Sikeres mentés!");
                Console.ReadKey();
            }
            else if (valasz == "5")
            {
                Betoltes(filmek);
                Console.ReadKey();
            }
            else if (valasz == "6") 
            {
                Console.WriteLine("Kilépés...");
                futas = false;
            }
            else
            {
                Console.WriteLine("Hibás menüpont");
            }
        }
    }
}
