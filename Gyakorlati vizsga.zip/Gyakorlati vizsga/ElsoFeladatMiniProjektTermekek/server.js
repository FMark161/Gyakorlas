const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "elsoprojekt"
});

const app = express();

app.use(express.json());
app.use(cors());

app.get('/test', (req, res)=>{
    res.json({Message: "A webszerver működik"});
});

app.get('/products', (req, res)=>{
    db.query("SELECT * FROM products", (err,result)=>{
        if(err)throw err;
        res.json(result);
    });
});

app.delete('/products/:id', (req, res)=>{
    const id = req.params.id;
    db.query("DELETE FROM products WHERE id = ?", [id], (err, result)=>{
        if (err) throw err;
        res.json({Message: "Sikeres törlés"});
    });
});

app.post('/products', (req, res)=>{
    const {name, price} = req.body;
    db.query("INSERT INTO products (name, price) VALUES (?, ?)", [name, price], (err, result)=>{
        if (err) throw err;
        res.json({Message: "Sikeres beszúrás"});
    });
});

app.put('/products/:id', (req, res)=>{
    const id = req.params.id;
    const {name, price} = req.body;
    db.query("UPDATE products SET name=?, price=? WHERE id = ?", [name, price, id], (err, result)=>{
        if (err) throw err;
        res.json({Message: "Sikeres módosítás"});
    });
});

app.listen(3000, ()=>{
    console.log("A webszerver fut a 3000-es porton");
});